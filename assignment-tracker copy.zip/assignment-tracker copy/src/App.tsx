import { Header } from "./components/Header";
import { Assignments } from "./components/Assignments";
import { useState } from 'react';

function App() {
  const [totalAssignments, setTotalAssignments] = useState(0);
  const [numCompletedAssignments, setNumCompletedAssignments] = useState(0);
  const [assignmentsList, setAssignmentsList] = useState([]);
  return (
    <>
      <Header 
        totalAssignments={totalAssignments} 
        setTotalAssignments={setTotalAssignments} 
        numCompletedAssignments={numCompletedAssignments} 
        setNumCompletedAssignments={setNumCompletedAssignments}
        assignmentsList={assignmentsList}
        setAssignmentsList={setAssignmentsList}
      />
      <Assignments 
        totalAssignments={totalAssignments} 
        setTotalAssignments={setTotalAssignments} 
        numCompletedAssignments={numCompletedAssignments} 
        setNumCompletedAssignments={setNumCompletedAssignments}
        assignmentsList={assignmentsList}
        setAssignmentsList={setAssignmentsList}
      />
    </>
  );
}

export default App;
