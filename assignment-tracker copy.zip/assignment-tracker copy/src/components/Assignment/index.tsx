import styles from "./assignment.module.css";
import { TbTrash } from "react-icons/tb";

type Props = {totalAssignments: number, setTotalAssignments: any, numCompletedAssignments: number, setNumCompletedAssignments: any}
export function Assignment(props: Props) {
  function handleCompletionToggle(){
    console.log("toggle completion");
    props.setNumCompletedAssignments(1); // fix later
  }
  function handleDelete(){
    if (props.totalAssignments > 0){
      props.setTotalAssignments(props.totalAssignments - 1);
    }
    console.log(`delete. total assignments: ${props.totalAssignments}`);
  }

  return (
    <div className={styles.assignment}>
      <button className={styles.checkContainer}
        onClick={handleCompletionToggle}
      >
        <div />
      </button>

      <p>Some Title</p>

      <button className={styles.deleteButton}
        onClick={handleDelete}
      >
        <TbTrash size={20} />
      </button>
    </div>
  );
}
