import { Assignment } from "../Assignment";
import styles from "./assignments.module.css";

type Props = {totalAssignments: number, setTotalAssignments: any, numCompletedAssignments: number, setNumCompletedAssignments: any, assignmentsList: any, setAssignmentsList: any}
export function Assignments(props: Props) {
  return (
    <section className={styles.assignments}>
      <header className={styles.header}>
        <div>
          <p>Created Assignments</p>
          <span>{props.totalAssignments}</span>
        </div>

        <div>
          <p className={styles.textPurple}>Completed Assignments</p>
          <span>{props.numCompletedAssignments} of {props.totalAssignments}</span>
        </div>
      </header>

      <div className={styles.list}>
        <Assignment 
          totalAssignments={props.totalAssignments} 
          setTotalAssignments={props.setTotalAssignments} 
          numCompletedAssignments={props.numCompletedAssignments}
          setNumCompletedAssignments={props.setNumCompletedAssignments}
        />
        {props.assignmentsList}
      </div>
    </section>
  );
}
