import styles from "./header.module.css";
import { AiOutlinePlusCircle } from "react-icons/ai";
import { uppercase } from "../../helpers/stringHelpers";
import { useState } from 'react';
import { Assignment } from "../Assignment";

type Props = {totalAssignments: number, setTotalAssignments: any, numCompletedAssignments: number, setNumCompletedAssignments: any, assignmentsList: any, setAssignmentsList: any}
export function Header(props: Props) {
  const [btnDisabled, setBtnDisabled] = useState(true);
  const [cursorStyle, setCursorStyle] = useState("default");
  const [btnColor, setBtnColor] = useState("lightgray");

  function handleChange(inputValue: string){
    if (inputValue == ""){
      setBtnDisabled(true);
      setCursorStyle("default");
      setBtnColor("lightgray");
    }else{
      setBtnDisabled(false);
      setCursorStyle("pointer");
      setBtnColor("#8284fa");
    }
  }
  function handleSubmit(){
    props.setTotalAssignments(props.totalAssignments + 1);
    console.log(`add. total assignments: ${props.totalAssignments}`);
    props.setAssignmentsList(props.assignmentsList.concat(
      <Assignment 
        totalAssignments={props.totalAssignments} 
        setTotalAssignments={props.setTotalAssignments} 
        numCompletedAssignments={props.numCompletedAssignments}
        setNumCompletedAssignments={props.setNumCompletedAssignments}
      />
  ));
  }

  return (
    <header className={styles.header}>
      {/* This is simply to show you how to use helper functions */}

      <h1>{uppercase("bcit")} Assignment Tracker</h1>
      <form 
        className={styles.newAssignmentForm}
        onSubmit={(e) => {
          e.preventDefault();
          handleSubmit();
        }
        }
      >
        <input 
          placeholder="Add a new assignment" 
          type="text" 
          onChange={(e) => handleChange(e.target.value)}
        />
        <button 
          disabled={btnDisabled}
          style={{cursor: cursorStyle, backgroundColor: btnColor}}
        >
          Create <AiOutlinePlusCircle size={20} />
        </button>
      </form>
    </header>
  );
}