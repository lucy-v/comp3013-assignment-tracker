const uppercase = (text: string) => {
  return text.toUpperCase();
};

export { uppercase };
